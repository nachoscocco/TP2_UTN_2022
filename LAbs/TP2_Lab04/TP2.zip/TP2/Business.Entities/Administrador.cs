﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Entities
{
    class Administrador : Usuario
    {
        public int LegajoAdmin { get; set; }
    }
}
