﻿using System;

namespace UI.Consola
{
    class Program
    {
        static void Main(string[] args)
        {
           new Usuarios().Menu();
        }
    }
}
